/*
 * EntregadorDeConvite.java
 *
 *
 */
package br.com.globalcode.threads;

public class EntregadorDeConvite extends Thread {
  
  private int identificador;
  private ListaConvidados listaConvidados;
  private boolean continuar = true;
  
  public EntregadorDeConvite(int id, ListaConvidados lista) {
    this.identificador = id;
    this.listaConvidados = lista;
    super.setName("entregador " + this.identificador);
  }
  
  public void run() {
    System.out.println(super.getName() + " iniciando atividades");
    boolean estaAberta = listaConvidados.isAberta();
    int quantidadePendente = listaConvidados.getQuantidadeEmailsPendentes();
    while (estaAberta || quantidadePendente > 0) {
      try {
        String email = listaConvidados.obterEmailConvidado();
        if (email != null) {
          System.out.println(super.getName() + " enviando email para " + email);
            // acesso ao servidor de email e envio da mensagem
            // simulando uma lentidao de ate 10 segundos
            Thread.sleep((int) (Math.random() * 10000)); 
        }
        System.out.println("... envio de convite para " + email + " conclu�do");
      } catch (Exception e) {
        e.printStackTrace();
      }
      // verificando situacao da lista
      estaAberta = listaConvidados.isAberta();
      quantidadePendente = listaConvidados.getQuantidadeEmailsPendentes();
    }
    System.out.println(super.getName() + " encerrando atividades");
  }
  
}
