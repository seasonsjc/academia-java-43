/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 */
public class TestaAgencia {

    public static void main(String[] args) {
        // Criacao da agencia
        Agencia a = new Agencia();
        // Inicializacao da agencia
        a.inicializaAgencia("2356", 104);
        // Impressao dos dados da agencia
        a.imprimeDados();
    }
}
