/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 * 
 * 1) Adicione os seguintes atributos na classe Cliente: 
 * - nome (String) 
 * - cpf (String)
 */
class Cliente {

    String nome;
    String cpf;
}
