/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 */
class TestaCliente {

    public static void main(String[] args) {
        // Criacao do cliente
        // Inicializacao do cliente
        // Impressao dos dados do cliente
    }
}
