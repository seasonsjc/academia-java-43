public class TesteRuntimeExceptions {

    public static void main(String[] args) {
        // Leitura do parametro digitado pelo usuario como parametro do main
        String parametro1 = args[0];
        int numero = Integer.parseInt(parametro1);
    }
}
